package com.cartstore.service;

import java.util.List;

import com.cartstore.bean.User;

public interface UserService {

	

	List<User> getAllUsers();

	List<User> createUser(User user);

}
