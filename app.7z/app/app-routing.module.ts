import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { AdddataComponent } from './adddata/adddata.component';
const routes: Routes = [
  
    {
        path : 'app-adddata',
        component : AdddataComponent
    }
    
];


@NgModule({

    imports: [RouterModule.forRoot(routes)],
  
    exports: [RouterModule]
  
  })
  
  export class AppRoutingModule { }